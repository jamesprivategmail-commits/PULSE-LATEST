import React, { useState, useEffect } from 'react';
import { NotificationItem, UserProfile } from '../types';
import { 
  subscribeToNotifications, 
  toggleFollowUser, 
  markNotificationsAsRead, 
  getSuggestedUsers, 
  subscribeToUserChats,
  checkIsFollowing,
  markChatAsRead
} from '../services/pulseDb';
import { 
  ArrowLeft, 
  Heart, 
  MessageCircle, 
  UserPlus, 
  Bell, 
  ShieldAlert, 
  CheckCheck, 
  ChevronRight,
  Info,
  Check,
  Plus,
  X,
  Send,
  UserCheck,
  Sparkles
} from 'lucide-react';
import { VerifiedBadge } from './VerifiedBadge';

interface InboxPageProps {
  isOpen: boolean;
  currentUser: UserProfile;
  onClose: () => void;
  onSelectUser: (handle: string, uid: string) => void;
  onOpenChat?: (user: { uid: string; handle: string; username: string; avatar: string; verified?: boolean }) => void;
  onOpenFollowList?: (mode: 'followers' | 'following' | 'requests', uid: string) => void;
  onOpenGroupChats?: () => void;
  onToast: (msg: string) => void;
}

interface ChatSnippet {
  uid: string;
  handle: string;
  username: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unreadCount: number;
  online: boolean;
  isBot?: boolean;
  verified?: boolean;
}

export const InboxPage: React.FC<InboxPageProps> = ({
  isOpen,
  currentUser,
  onClose,
  onSelectUser,
  onOpenChat,
  onOpenFollowList,
  onToast
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [activeChannel, setActiveChannel] = useState<'hub' | 'followers' | 'activity' | 'system' | 'reports'>('hub');
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({});
  const [suggestedCreators, setSuggestedCreators] = useState<UserProfile[]>([]);
  const [appealText, setAppealText] = useState('');
  const [appealSent, setAppealSent] = useState(false);

  // Active Direct Chats from Firestore
  const [chatThreads, setChatThreads] = useState<ChatSnippet[]>([]);

  useEffect(() => {
    if (!isOpen || !currentUser) return;

    const unsubscribeNotifs = subscribeToNotifications(currentUser.uid, (items) => {
      setNotifications(items);
    });

    const unsubscribeChats = subscribeToUserChats(currentUser.uid, (loadedChats) => {
      setChatThreads(loadedChats || []);
    });

    getSuggestedUsers(currentUser.uid).then(creators => {
      if (creators && creators.length > 0) {
        setSuggestedCreators(creators.filter(c => c.uid !== currentUser.uid).slice(0, 8));
      } else {
        setSuggestedCreators([]);
      }
    }).catch(() => {});

    return () => {
      unsubscribeNotifs();
      unsubscribeChats();
    };
  }, [isOpen, currentUser?.uid]);

  if (!isOpen) return null;

  const handleMarkAllRead = async () => {
    try {
      await markNotificationsAsRead(currentUser.uid);
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      onToast('All notifications marked as read');
    } catch (e) {}
  };

  const handleToggleFollow = async (whoUid: string, handle: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const isNowFollowing = !followingMap[whoUid];
    setFollowingMap(prev => ({ ...prev, [whoUid]: isNowFollowing }));
    await toggleFollowUser(currentUser.uid, whoUid, currentUser);
    onToast(isNowFollowing ? `Following ${handle}` : `Unfollowed ${handle}`);
  };

  const handleStartChat = async (user: { chatId?: string; uid: string; handle: string; username: string; avatar: string; verified?: boolean }) => {
    if (user.chatId && currentUser?.uid) {
      markChatAsRead(user.chatId, currentUser.uid);
    }
    if (onOpenChat) {
      onOpenChat(user);
    } else {
      onSelectUser(user.handle, user.uid);
    }
  };

  const handleDismissSuggested = (uid: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSuggestedCreators(prev => prev.filter(c => c.uid !== uid));
  };

  const handleSendAppeal = () => {
    if (!appealText.trim()) {
      onToast('Please write your appeal or inquiry');
      return;
    }
    setAppealSent(true);
    onToast('Appeal submitted to Trust & Safety Team ✅');
    setAppealText('');
  };

  const followerNotifs = notifications.filter(n => n.kind === 'follow');
  const activityNotifs = notifications.filter(n => n.kind === 'like' || n.kind === 'comment' || n.kind === 'mention' || n.kind === 'repost' || n.kind === 'live');
  const systemNotifs = notifications.filter(n => n.kind === 'admin');

  const unreadFollowersCount = followerNotifs.filter(n => !n.read).length;
  const unreadActivityCount = activityNotifs.filter(n => !n.read).length;
  const unreadSystemCount = systemNotifs.filter(n => !n.read).length;

  return (
    <div className="w-full h-full bg-black text-white flex flex-col select-none overflow-hidden pb-12 font-sans">
      {/* 1. TOP HEADER */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-white/10 shrink-0 bg-black">
        <div className="flex items-center gap-2">
          {activeChannel !== 'hub' ? (
            <button
              onClick={() => setActiveChannel('hub')}
              className="p-1 rounded-full text-white hover:opacity-70 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={() => onOpenFollowList?.('followers', currentUser.uid)}
              className="p-1 text-white hover:opacity-70 cursor-pointer"
              title="Add contacts / friends"
            >
              <UserPlus className="w-4 h-4 stroke-[2.2]" />
            </button>
          )}

          <div className="flex items-center gap-1.5">
            <h2 className="font-bold text-xs text-white tracking-tight">
              {activeChannel === 'hub' && 'Inbox'}
              {activeChannel === 'followers' && 'New Followers'}
              {activeChannel === 'activity' && 'Activity'}
              {activeChannel === 'system' && 'System Notifications'}
              {activeChannel === 'reports' && 'Reports & Warnings'}
            </h2>
            {activeChannel === 'hub' && (
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            )}
          </div>
        </div>

        <div className="flex items-center gap-1">
          {notifications.some(n => !n.read) && (
            <button
              onClick={handleMarkAllRead}
              className="p-1 text-neutral-400 hover:text-white cursor-pointer text-[10px] flex items-center gap-1"
              title="Mark all as read"
            >
              <CheckCheck className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* VIEW: MAIN INBOX HUB */}
      {activeChannel === 'hub' && (
        <div className="flex-1 overflow-y-auto">
          {/* 1. ACTIVITY & NOTIFICATION CHANNELS */}
          <div className="divide-y divide-white/5">
            {/* 1. New followers */}
            <div
              onClick={() => setActiveChannel('followers')}
              className="flex items-center justify-between px-3 py-1.5 hover:bg-neutral-900 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-full bg-[#20D5EC] text-black flex items-center justify-center shrink-0 shadow-xs font-bold">
                  <UserPlus className="w-3.5 h-3.5 stroke-[2.2]" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-[11.5px] font-bold text-white leading-tight">New followers</h4>
                  <p className="text-[10px] text-neutral-400 truncate leading-tight mt-0.5">
                    {followerNotifs.length > 0 
                      ? `${followerNotifs[0].who} started following you` 
                      : 'No new followers yet'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {unreadFollowersCount > 0 && (
                  <span className="w-4 h-4 rounded-full bg-[#fe2c55] text-white text-[8.5px] font-bold flex items-center justify-center">
                    {unreadFollowersCount}
                  </span>
                )}
                <ChevronRight className="w-3 h-3 text-neutral-500" />
              </div>
            </div>

            {/* 2. Activity / Likes */}
            <div
              onClick={() => setActiveChannel('activity')}
              className="flex items-center justify-between px-3 py-1.5 hover:bg-neutral-900 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-full bg-[#fe2c55] text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Heart className="w-3.5 h-3.5 fill-white stroke-none" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-[11.5px] font-bold text-white leading-tight">Activity</h4>
                  <p className="text-[10px] text-neutral-400 truncate leading-tight mt-0.5">
                    {activityNotifs.length > 0 
                      ? `${activityNotifs[0].who} ${activityNotifs[0].text || 'interacted with you'}`
                      : 'No new activity yet'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {unreadActivityCount > 0 && (
                  <span className="w-4 h-4 rounded-full bg-[#fe2c55] text-white text-[8.5px] font-bold flex items-center justify-center">
                    {unreadActivityCount}
                  </span>
                )}
                <ChevronRight className="w-3 h-3 text-neutral-500" />
              </div>
            </div>

            {/* 3. System notifications */}
            <div
              onClick={() => setActiveChannel('system')}
              className="flex items-center justify-between px-3 py-1.5 hover:bg-neutral-900 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-full bg-neutral-800 text-white flex items-center justify-center shrink-0 shadow-xs border border-white/10">
                  <Bell className="w-3.5 h-3.5 stroke-[2.2]" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-[11.5px] font-bold text-white leading-tight">System notifications</h4>
                  <p className="text-[10px] text-neutral-400 truncate leading-tight mt-0.5">
                    {systemNotifs.length > 0
                      ? (systemNotifs[0].text || 'System updates')
                      : 'Account health & security notifications'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {unreadSystemCount > 0 && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#fe2c55]" />
                )}
                <ChevronRight className="w-3 h-3 text-neutral-500" />
              </div>
            </div>

            {/* 4. Safety & Warning Reports */}
            <div
              onClick={() => setActiveChannel('reports')}
              className="flex items-center justify-between px-3 py-1.5 hover:bg-neutral-900 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-full bg-amber-600/30 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0 shadow-xs">
                  <ShieldAlert className="w-3.5 h-3.5 stroke-[2.2]" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-[11.5px] font-bold text-white flex items-center gap-1 leading-tight">
                    Reports &amp; Warnings
                  </h4>
                  <p className="text-[10px] text-neutral-400 truncate leading-tight mt-0.5">
                    {currentUser.warningMessage || 'Account health: Excellent · Good standing'}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-3 h-3 text-neutral-500" />
            </div>
          </div>

          {/* 5. DIRECT MESSAGES FEED */}
          <div className="mt-1 border-t border-white/10">
            <div className="px-3 py-1 flex items-center justify-between bg-neutral-950 border-b border-white/10">
              <span className="text-[9.5px] font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1">
                <MessageCircle className="w-2.5 h-2.5 text-[#20D5EC]" /> Direct Messages
              </span>
              {chatThreads.some(t => t.unreadCount > 0) && (
                <span className="text-[8px] font-bold text-[#fe2c55] bg-rose-500/20 px-1.5 py-0.2 rounded-full border border-rose-500/30">
                  {chatThreads.reduce((acc, t) => acc + (t.unreadCount || 0), 0)} unread
                </span>
              )}
            </div>

            {chatThreads.length === 0 ? (
              <div className="px-3 py-4 text-center text-[10.5px] text-neutral-500">
                No active conversations yet. Start a conversation with a creator below!
              </div>
            ) : (
              <div className="divide-y divide-white/5">
                {chatThreads.map((t) => (
                  <div
                    key={t.uid}
                    onClick={() => handleStartChat(t)}
                    className={`flex items-center justify-between px-3 py-1.5 hover:bg-neutral-900 cursor-pointer transition-colors ${
                      t.unreadCount > 0 ? 'bg-rose-950/20' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="relative">
                        <img
                          src={t.avatar}
                          alt={t.username}
                          className="w-7 h-7 rounded-full object-cover border border-white/20 shrink-0"
                          loading="lazy"
                        />
                        {t.online && (
                          <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-green-500 border-2 border-black" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-[11px] font-bold text-white flex items-center gap-1 leading-tight">
                          <span className="truncate">{t.username}</span>
                          {t.verified && <VerifiedBadge size="xs" />}
                        </h4>
                        <p className={`text-[10px] truncate leading-tight mt-0.5 ${t.unreadCount > 0 ? 'font-bold text-white' : 'text-neutral-400'}`}>
                          {t.lastMessage}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-0.5 shrink-0">
                      <span className="text-[8.5px] text-neutral-500">{t.time}</span>
                      {t.unreadCount > 0 ? (
                        <span className="min-w-[14px] h-[14px] px-1 rounded-full bg-[#fe2c55] text-white text-[8px] font-bold flex items-center justify-center shadow-xs">
                          {t.unreadCount > 9 ? '9+' : t.unreadCount}
                        </span>
                      ) : null}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 2. SUGGESTED ACCOUNTS SECTION (Only real accounts from Firestore) */}
          {suggestedCreators.length > 0 && (
            <div className="mt-2 px-3 pb-3">
              <div className="flex items-center justify-between pb-1">
                <span className="text-[10.5px] font-bold text-neutral-300 flex items-center gap-1">
                  Suggested creators <Info className="w-2.5 h-2.5 text-neutral-500" />
                </span>
              </div>

              <div className="divide-y divide-white/5">
                {suggestedCreators.map((c) => (
                  <div
                    key={c.uid}
                    onClick={() => onSelectUser(c.handle, c.uid)}
                    className="flex items-center justify-between py-1.5 hover:bg-neutral-900 rounded-lg px-1 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <img
                        src={c.photoURL}
                        alt={c.username}
                        className="w-7.5 h-7.5 rounded-full object-cover border border-white/20 shrink-0"
                      />
                      <div className="min-w-0">
                        <h4 className="text-[11px] font-bold text-white truncate flex items-center gap-1">
                          {c.username}
                          {c.verified && <VerifiedBadge size="xs" />}
                        </h4>
                        <p className="text-[9.5px] text-neutral-400 truncate">
                          {c.handle}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={(e) => handleToggleFollow(c.uid, c.handle, e)}
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition-colors shadow-xs ${
                          followingMap[c.uid]
                            ? 'bg-neutral-800 text-white border border-white/10 hover:bg-neutral-700'
                            : 'bg-[#fe2c55] hover:bg-[#e0244a] text-white'
                        }`}
                      >
                        {followingMap[c.uid] ? 'Following' : 'Follow'}
                      </button>
                      <button
                        onClick={(e) => handleDismissSuggested(c.uid, e)}
                        className="p-1 text-neutral-500 hover:text-white cursor-pointer"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* VIEW: NEW FOLLOWERS CHANNEL */}
      {activeChannel === 'followers' && (
        <div className="flex-1 overflow-y-auto p-3 divide-y divide-white/5">
          {followerNotifs.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center text-neutral-400">
              <div className="w-8 h-8 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center mb-1.5 text-neutral-500">
                <UserPlus className="w-4 h-4 stroke-[1.5]" />
              </div>
              <p className="text-[11px] font-semibold text-neutral-200">No new followers yet</p>
              <p className="text-[9.5px] text-neutral-500 mt-0.5">When other creators follow you, they'll appear right here.</p>
            </div>
          ) : (
            followerNotifs.map((n) => (
              <div key={n.id} className="py-2 flex items-center justify-between">
                <div 
                  onClick={() => onSelectUser(n.who, n.whoUid || '')}
                  className="flex items-center gap-2 cursor-pointer min-w-0"
                >
                  <img
                    src={n.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(n.whoUid || n.who)}`}
                    alt={n.who}
                    className="w-7.5 h-7.5 rounded-full object-cover shrink-0 border border-white/10"
                  />
                  <div className="min-w-0">
                    <b className="text-[11px] text-white block truncate">{n.who}</b>
                    <span className="text-[9.5px] text-neutral-400">Started following you · {n.time || 'recently'}</span>
                  </div>
                </div>
                {n.whoUid && (
                  <button
                    onClick={(e) => handleToggleFollow(n.whoUid!, n.who, e)}
                    className={`px-2.5 py-0.5 font-bold rounded-full text-[10px] shrink-0 cursor-pointer ${
                      followingMap[n.whoUid]
                        ? 'bg-neutral-800 text-white border border-white/10 hover:bg-neutral-700'
                        : 'bg-[#fe2c55] text-white hover:bg-[#e0244a]'
                    }`}
                  >
                    {followingMap[n.whoUid] ? 'Following' : 'Follow back'}
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* VIEW: ACTIVITY CHANNEL */}
      {activeChannel === 'activity' && (
        <div className="flex-1 overflow-y-auto p-3 divide-y divide-white/5">
          {activityNotifs.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center text-neutral-400">
              <div className="w-8 h-8 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center mb-1.5 text-neutral-500">
                <Heart className="w-4 h-4 stroke-[1.5]" />
              </div>
              <p className="text-[11px] font-semibold text-neutral-200">No recent activity</p>
              <p className="text-[9.5px] text-neutral-500 mt-0.5">Likes, comments, and mentions on your posts will appear here.</p>
            </div>
          ) : (
            activityNotifs.map((n) => (
              <div key={n.id} className="py-2 flex items-center justify-between">
                <div 
                  onClick={() => onSelectUser(n.who, n.whoUid || '')}
                  className="flex items-center gap-2 cursor-pointer min-w-0"
                >
                  <img
                    src={n.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(n.whoUid || n.who)}`}
                    alt={n.who}
                    className="w-7.5 h-7.5 rounded-full object-cover shrink-0 border border-white/10"
                  />
                  <div className="min-w-0">
                    <b className="text-[11px] text-white block truncate">{n.who}</b>
                    <span className="text-[9.5px] text-neutral-400">{n.text || 'Interacted with your content'} · {n.time || 'recently'}</span>
                  </div>
                </div>
                <div className="shrink-0 text-neutral-400">
                  {n.kind === 'like' && <Heart className="w-3.5 h-3.5 fill-[#fe2c55] text-[#fe2c55]" />}
                  {n.kind === 'comment' && <MessageCircle className="w-3.5 h-3.5 text-blue-400" />}
                  {n.kind === 'live' && <Sparkles className="w-3.5 h-3.5 text-[#ff5361]" />}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* VIEW: SYSTEM NOTIFICATIONS CHANNEL */}
      {activeChannel === 'system' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {systemNotifs.length === 0 ? (
            <div className="p-2.5 bg-neutral-900 rounded-xl border border-white/10 space-y-1">
              <b className="text-[11px] font-bold text-white block">Account Status: Good Standing</b>
              <p className="text-[10px] text-neutral-400 leading-snug">
                Welcome to Pulse. Start uploading videos, connecting with friends, and sharing messages.
              </p>
            </div>
          ) : (
            systemNotifs.map((n) => (
              <div key={n.id} className="p-2.5 bg-neutral-900 rounded-xl border border-white/10 space-y-0.5">
                <b className="text-[11px] font-bold text-white block">{n.who || 'System Notice'}</b>
                <p className="text-[10px] text-neutral-300">{n.text}</p>
                <span className="text-[8.5px] text-neutral-500 block pt-0.5">{n.time || 'Recent'}</span>
              </div>
            ))
          )}
        </div>
      )}

      {/* VIEW: REPORTS & SAFETY WARNINGS */}
      {activeChannel === 'reports' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
          <div className="p-2.5 bg-amber-950/30 border border-amber-500/30 rounded-xl space-y-1">
            <div className="flex items-center gap-1.5 text-amber-400">
              <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
              <h4 className="text-[11px] font-bold">Account Health &amp; Trust Status</h4>
            </div>
            <p className="text-[10px] text-neutral-300 leading-snug">
              {currentUser.warningMessage || 'No active strikes or restrictions on your account. All community guidelines are in good standing.'}
            </p>
          </div>

          <div className="p-2.5 bg-neutral-900 border border-white/10 rounded-xl space-y-2">
            <h4 className="text-[11px] font-bold text-white">Submit Inquiry / Appeal to Safety Team</h4>
            <textarea
              value={appealText}
              onChange={(e) => setAppealText(e.target.value)}
              rows={2}
              placeholder="If your account received a warning or restriction, explain the situation here..."
              className="w-full bg-neutral-950 border border-white/10 rounded-lg p-2 text-[10.5px] text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#20D5EC] resize-none"
            />
            <button
              onClick={handleSendAppeal}
              className="w-full h-7 bg-[#fe2c55] hover:bg-[#e0244a] text-white font-bold rounded-lg text-[10.5px] flex items-center justify-center gap-1 shadow-xs cursor-pointer"
            >
              <Send className="w-3 h-3" /> Submit Appeal
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
