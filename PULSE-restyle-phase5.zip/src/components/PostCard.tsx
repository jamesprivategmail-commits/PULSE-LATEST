import React, { useRef, useState, useEffect } from 'react';
import { VideoPost, UserProfile } from '../types';
import {
  toggleVideoLike,
  toggleVideoSave,
  toggleRepostVideo,
  checkUserLikedVideo,
  checkUserSavedVideo,
  checkIsFollowing,
  toggleFollowUser,
  recordVideoView
} from '../services/pulseDb';
import { formatCount } from '../utils/formatters';
import {
  Heart,
  MessageCircle,
  Bookmark,
  Share2,
  MoreVertical,
  Repeat,
  Check
} from 'lucide-react';
import { VerifiedBadge } from './VerifiedBadge';

interface PostCardProps {
  video: VideoPost;
  currentUser: UserProfile | null;
  isFollowing?: boolean;
  onOpenComments: (video: VideoPost) => void;
  onOpenProfile: (handle: string, uid: string) => void;
  onOpenShare?: (video: VideoPost) => void;
  onOpenReport: (type: 'video', id: string, handle?: string) => void;
  onFollowToggle?: (targetUid: string, isFollowing: boolean) => void;
  onToast: (msg: string) => void;
  onRequireAuth: () => void;
}

// Card version of a post for the scrollable Home feed — mirrors the design's
// `.post` layout (header row, media, action row, likes, caption) instead of
// VideoSlide's full-screen swipe layout. Reuses the same data + backend
// actions as the video feed so likes/saves/reposts/follows stay in sync.
export const PostCard: React.FC<PostCardProps> = ({
  video,
  currentUser,
  isFollowing: propIsFollowing,
  onOpenComments,
  onOpenProfile,
  onOpenShare,
  onOpenReport,
  onFollowToggle,
  onToast,
  onRequireAuth
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [liked, setLiked] = useState(!!video.isLiked);
  const [likeCount, setLikeCount] = useState(video.likeCount || 0);
  const [saved, setSaved] = useState(!!video.isSaved);
  const [reposted, setReposted] = useState(!!video.isReposted);
  const [isFollowing, setIsFollowing] = useState(propIsFollowing || false);
  const [followPending, setFollowPending] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const viewRecordedRef = useRef(false);
  const isLikingRef = useRef(false);

  useEffect(() => {
    if (propIsFollowing !== undefined) setIsFollowing(propIsFollowing);
  }, [propIsFollowing]);

  useEffect(() => {
    if (!currentUser) return;
    checkUserLikedVideo(video.id, currentUser.uid).then(setLiked);
    checkUserSavedVideo(video.id, currentUser.uid).then(setSaved);
    if (propIsFollowing === undefined && video.ownerUid && video.ownerUid !== currentUser.uid) {
      checkIsFollowing(currentUser.uid, video.ownerUid).then(setIsFollowing);
    }
  }, [video.id, currentUser?.uid]);

  const handleLike = async () => {
    if (!currentUser) return onRequireAuth();
    // Guard against overlapping calls (rapid re-taps): two concurrent
    // toggleVideoLike calls can both read the "not liked" doc before either
    // write commits, double-incrementing likeCount server-side.
    if (isLikingRef.current) return;
    isLikingRef.current = true;
    const next = !liked;
    setLiked(next);
    setLikeCount(c => Math.max(0, c + (next ? 1 : -1)));
    try {
      await toggleVideoLike(video.id, currentUser);
    } catch {
      setLiked(!next);
      setLikeCount(c => Math.max(0, c + (next ? -1 : 1)));
    } finally {
      isLikingRef.current = false;
    }
  };

  const handleSave = async () => {
    if (!currentUser) return onRequireAuth();
    const next = !saved;
    setSaved(next);
    try {
      await toggleVideoSave(video.id, currentUser);
      onToast(next ? 'Saved' : 'Removed from saved');
    } catch {
      setSaved(!next);
    }
  };

  const handleRepost = async () => {
    if (!currentUser) return onRequireAuth();
    const next = !reposted;
    setReposted(next);
    try {
      await toggleRepostVideo(video, currentUser);
      onToast(next ? 'Reposted to your profile! 🔁' : 'Removed repost');
    } catch {
      setReposted(!next);
    }
  };

  const handleFollow = async () => {
    if (!currentUser) return onRequireAuth();
    if (followPending) return;
    setFollowPending(true);
    try {
      const next = await toggleFollowUser(currentUser.uid, video.ownerUid, currentUser, video.ownerHandle);
      setIsFollowing(next);
      onFollowToggle?.(video.ownerUid, next);
    } finally {
      setFollowPending(false);
    }
  };

  const handleMediaVisible = () => {
    if (viewRecordedRef.current || !currentUser) return;
    viewRecordedRef.current = true;
    recordVideoView(video.id).catch(() => {});
  };

  const isImage = video.mediaType === 'image' || video.mediaType === 'carousel';

  return (
    <article className="border-t border-white/[0.075] pb-4">
      {/* Header */}
      <div className="min-h-[63px] px-3.5 py-2.5 flex items-center justify-between">
        <div
          className="flex items-center gap-2 cursor-pointer min-w-0"
          onClick={() => onOpenProfile(video.ownerHandle, video.ownerUid)}
        >
          <img
            src={video.ownerAvatar}
            alt={video.ownerHandle}
            className="w-10 h-10 rounded-full object-cover shrink-0"
          />
          <div className="min-w-0">
            <div className="flex items-center gap-1 text-xs font-bold text-white truncate">
              <span className="truncate">{video.ownerUsername || video.ownerHandle}</span>
              {video.verified && <VerifiedBadge size="xs" />}
            </div>
            <div className="text-[9px] text-neutral-500 mt-0.5">
              {timeAgo(video.createdAt)}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {currentUser?.uid !== video.ownerUid && (
            <button
              onClick={handleFollow}
              disabled={followPending}
              className={`h-[31px] px-2.5 rounded-[9px] text-[9px] font-bold border transition-colors disabled:opacity-60 ${
                isFollowing
                  ? 'bg-neutral-900 text-white border-white/10'
                  : 'bg-[#171719] text-neutral-200 border-white/[0.13]'
              }`}
            >
              {isFollowing ? 'Following' : 'Follow'}
            </button>
          )}
          <div className="relative">
            <button
              onClick={() => setShowMenu(v => !v)}
              className="w-[34px] h-[34px] rounded-[10px] flex items-center justify-center text-neutral-400 hover:bg-white/5"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
            {showMenu && (
              <div className="absolute right-0 top-9 z-20 w-40 bg-[#111113] border border-white/10 rounded-xl shadow-2xl overflow-hidden">
                <button
                  onClick={() => { setShowMenu(false); onOpenReport('video', video.id, video.ownerHandle); }}
                  className="w-full text-left px-3 py-2.5 text-[11px] text-red-400 hover:bg-white/5"
                >
                  Report
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Media */}
      <div
        className="w-full bg-[#0d0d0f] cursor-pointer"
        onDoubleClick={() => { if (!liked) handleLike(); onToast('❤️ Liked'); }}
        onClick={handleMediaVisible}
      >
        {isImage ? (
          <img
            src={video.coverUrl || video.images?.[0] || video.src}
            alt=""
            className="w-full max-h-[690px] min-h-[275px] object-cover block"
          />
        ) : (
          <video
            ref={videoRef}
            src={video.src}
            poster={video.coverUrl}
            className="w-full max-h-[690px] min-h-[275px] object-cover block"
            controls
            playsInline
            preload="metadata"
          />
        )}
      </div>

      {/* Content */}
      <div className="px-3.5 pt-2">
        <div className="flex items-center gap-0.5">
          <button
            onClick={handleLike}
            className={`w-[41px] h-[41px] rounded-xl flex items-center justify-center transition-transform active:scale-90 ${
              liked ? 'text-[#ff5361]' : 'text-neutral-300'
            }`}
          >
            <Heart className="w-5 h-5" fill={liked ? 'currentColor' : 'none'} />
          </button>
          <button
            onClick={() => onOpenComments(video)}
            className="w-[41px] h-[41px] rounded-xl flex items-center justify-center text-neutral-300 active:scale-90 transition-transform"
          >
            <MessageCircle className="w-5 h-5" />
          </button>
          <button
            onClick={handleRepost}
            className={`w-[41px] h-[41px] rounded-xl flex items-center justify-center transition-transform active:scale-90 ${
              reposted ? 'text-[#36d781]' : 'text-neutral-300'
            }`}
          >
            <Repeat className="w-5 h-5" />
          </button>
          <button
            onClick={() => onOpenShare?.(video)}
            className="w-[41px] h-[41px] rounded-xl flex items-center justify-center text-neutral-300 active:scale-90 transition-transform"
          >
            <Share2 className="w-5 h-5" />
          </button>
          <button
            onClick={handleSave}
            className={`w-[41px] h-[41px] rounded-xl flex items-center justify-center ml-auto transition-transform active:scale-90 ${
              saved ? 'text-[#ffbd1a]' : 'text-neutral-300'
            }`}
          >
            <Bookmark className="w-5 h-5" fill={saved ? 'currentColor' : 'none'} />
          </button>
        </div>

        <div className="mt-0.5 text-[11px] font-extrabold text-white">
          {formatCount(likeCount)} likes
        </div>

        {video.caption && (
          <div className="mt-1.5 text-xs text-neutral-200 leading-snug">
            <strong className="text-white mr-1">{video.ownerUsername || video.ownerHandle}</strong>
            {video.caption}
          </div>
        )}

        {video.commentCount > 0 && (
          <div
            onClick={() => onOpenComments(video)}
            className="mt-1.5 text-[10px] text-neutral-500 cursor-pointer"
          >
            View {formatCount(video.commentCount)} comments
          </div>
        )}
      </div>
    </article>
  );
};

function timeAgo(ts: number): string {
  const diff = Math.max(0, Date.now() - (ts || Date.now()));
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}
