import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, ChatMessage } from '../types';
import { 
  getChatId, 
  subscribeToChatMessages, 
  sendChatMessage, 
  deleteChatMessage, 
  reactToChatMessage,
  subscribeToUserProfile,
  markChatAsRead
} from '../services/pulseDb';
import { VoiceNotePlayer } from './VoiceNotePlayer';
import { VoiceNoteRecorder } from './VoiceNoteRecorder';
import { 
  ArrowLeft, 
  Send, 
  Image as ImageIcon, 
  Trash2, 
  Smile, 
  Check, 
  CheckCheck,
  Mic,
  MicOff,
  Search,
  Pin,
  Forward,
  Reply,
  Palette,
  Volume2,
  BellOff,
  Bell,
  MoreVertical,
  X,
  Sparkles,
  Play,
  Pause,
  Phone,
  Video
} from 'lucide-react';
import { VerifiedBadge } from './VerifiedBadge';

interface ChatPageProps {
  isOpen: boolean;
  currentUser: UserProfile;
  recipient: {
    uid: string;
    handle: string;
    avatar: string;
    username?: string;
  } | null;
  onClose: () => void;
  onToast: (msg: string) => void;
  onOpenProfile?: (handle: string, uid: string) => void;
  onStartCall?: (recipient: { uid: string; handle: string; username?: string; avatar: string }, type: 'voice' | 'video') => void;
}

const EMOJI_REACTIONS = ['❤️', '🔥', '😂', '👏', '😮', '👍', '🙏', '🎉'];

const CHAT_WALLPAPERS: Record<string, { name: string; bgClass: string; accentColor: string }> = {
  default: { name: 'Default Dark', bgClass: 'bg-[#121214]', accentColor: '#25f4ee' },
  cyber: { name: 'Cyber Neon', bgClass: 'bg-gradient-to-b from-[#0d1b2a] via-[#1b263b] to-[#0d1b2a]', accentColor: '#25f4ee' },
  sunset: { name: 'Sunset Glow', bgClass: 'bg-gradient-to-b from-[#2b1055] via-[#4a154b] to-[#1a0826]', accentColor: '#ff2b54' },
  midnight: { name: 'Midnight Obsidian', bgClass: 'bg-[#090a0f]', accentColor: '#a855f7' },
  matrix: { name: 'Matrix Emerald', bgClass: 'bg-gradient-to-b from-[#051d14] via-[#022c22] to-[#04120c]', accentColor: '#10b981' }
};

export const ChatPage: React.FC<ChatPageProps> = ({
  isOpen,
  currentUser,
  recipient,
  onClose,
  onToast,
  onOpenProfile,
  onStartCall
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [activeReactionMsgId, setActiveReactionMsgId] = useState<string | null>(null);
  const [replyingTo, setReplyingTo] = useState<ChatMessage | null>(null);
  const [pinnedMessage, setPinnedMessage] = useState<ChatMessage | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [wallpaperTheme, setWallpaperTheme] = useState<string>('default');
  const [isMuted, setIsMuted] = useState(false);

  // Voice recording state
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);

  // GIF Picker state
  const [showGifPicker, setShowGifPicker] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [liveRecipient, setLiveRecipient] = useState<UserProfile | null>(null);

  const chatId = recipient ? getChatId(currentUser.uid, recipient.uid) : '';

  useEffect(() => {
    if (!recipient?.uid) return;
    const unsubscribeProfile = subscribeToUserProfile(recipient.uid, (p) => {
      if (p) setLiveRecipient(p);
    });
    return () => unsubscribeProfile();
  }, [recipient?.uid]);

  useEffect(() => {
    if (!isOpen || !recipient || !chatId) return;

    // Mark as read immediately on open
    if (currentUser?.uid) {
      markChatAsRead(chatId, currentUser.uid);
    }

    const unsubscribe = subscribeToChatMessages(chatId, (loadedMessages) => {
      setMessages(loadedMessages);
      if (currentUser?.uid) {
        markChatAsRead(chatId, currentUser.uid);
      }
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });

    return () => unsubscribe();
  }, [isOpen, recipient?.uid, chatId, currentUser?.uid]);

  if (!isOpen || !recipient) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = inputText.trim();
    if ((!text && !mediaUrl) || sending) return;

    setSending(true);
    try {
      let finalMessage = text;
      if (replyingTo) {
        finalMessage = `↩️ Replying to "${replyingTo.text.slice(0, 30)}...":\n${text}`;
      }
      await sendChatMessage(
        chatId, 
        currentUser, 
        finalMessage || (mediaUrl ? '📷 Photo' : ''), 
        recipient.uid, 
        mediaUrl || undefined,
        {
          mediaType: mediaUrl ? 'image' : 'text'
        }
      );
      setInputText('');
      setMediaUrl(null);
      setReplyingTo(null);
    } catch (err: any) {
      onToast('Failed to send message: ' + (err.message || 'Error'));
    } finally {
      setSending(false);
    }
  };

  // Upload Audio Blob to backend & send genuine Voice Note
  const handleSendVoiceBlob = async (audioBlob: Blob, durationSeconds: number) => {
    try {
      // 1. Read blob into Data URL
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(audioBlob);
      });

      let finalAudioUrl = dataUrl;

      // 2. Upload to /api/upload
      try {
        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            dataUrl,
            type: 'audio/webm'
          })
        });
        const data = await res.json();
        if (data.success && data.url) {
          finalAudioUrl = data.url;
        }
      } catch (uploadErr) {
        console.warn('Server upload notice, using direct data URI fallback:', uploadErr);
      }

      // 3. Send message with audio url & voiceDuration
      await sendChatMessage(
        chatId, 
        currentUser, 
        '🎙️ Voice Note', 
        recipient.uid, 
        finalAudioUrl, 
        {
          mediaType: 'voice',
          voiceDuration: durationSeconds
        }
      );

      setIsRecordingVoice(false);
      onToast('Voice note sent! 🎙️');
    } catch (err: any) {
      console.error('Send voice note error:', err);
      onToast('Failed to send voice note');
    }
  };

  const handleSendGif = async (gifUrl: string) => {
    setShowGifPicker(false);
    try {
      await sendChatMessage(chatId, currentUser, '👾 GIF', recipient.uid, gifUrl, {
        mediaType: 'gif',
        gifUrl
      });
      onToast('GIF sent!');
    } catch (e) {
      onToast('Error sending GIF');
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      onToast('Please select an image file');
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setMediaUrl(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDelete = async (messageId: string) => {
    try {
      await deleteChatMessage(chatId, messageId);
      onToast('Message un-sent');
    } catch (e) {
      onToast('Error deleting message');
    }
  };

  const handleReact = async (messageId: string, emoji: string) => {
    try {
      await reactToChatMessage(chatId, messageId, emoji, currentUser.uid);
      setActiveReactionMsgId(null);
    } catch (e) {}
  };

  const handleTogglePin = (msg: ChatMessage) => {
    if (pinnedMessage?.id === msg.id) {
      setPinnedMessage(null);
      onToast('Unpinned message');
    } else {
      setPinnedMessage(msg);
      onToast('Pinned message to chat header 📌');
    }
  };

  const handleInitiateCall = (type: 'voice' | 'video') => {
    if (onStartCall) {
      onStartCall({
        uid: recipient.uid,
        handle: displayHandle,
        username: displayUsername,
        avatar: displayAvatar
      }, type);
    } else {
      onToast(`Starting ${type} call...`);
    }
  };

  const filteredMessages = searchQuery.trim()
    ? messages.filter(m => (m.text || '').toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  const currentTheme = CHAT_WALLPAPERS[wallpaperTheme] || CHAT_WALLPAPERS.default;

  const displayAvatar = liveRecipient?.photoURL || recipient.avatar;
  const displayUsername = liveRecipient?.username || recipient.username || recipient.handle;
  const displayHandle = liveRecipient?.handle || recipient.handle;
  const isVerified = (liveRecipient?.verified ?? (recipient as any).verified) === true;

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between max-w-[480px] mx-auto select-none font-sans">
      
      {/* Header */}
      <div className="px-3 py-1.5 bg-black border-b border-white/10 flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <button onClick={onClose} className="p-1 rounded-lg text-neutral-400 hover:text-white cursor-pointer shrink-0">
            <ArrowLeft className="w-4 h-4" />
          </button>
          
          <div 
            onClick={() => onOpenProfile && onOpenProfile(displayHandle, recipient.uid)}
            className="flex items-center gap-1.5 cursor-pointer hover:opacity-80 transition-opacity min-w-0"
          >
            <div className="relative shrink-0">
              <img
                src={displayAvatar}
                alt={displayHandle}
                className="w-7 h-7 rounded-full object-cover border border-white/20"
              />
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 border border-black absolute bottom-0 right-0" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-[11.5px] font-bold text-white truncate max-w-[110px] sm:max-w-[160px]">{displayUsername}</span>
                {isVerified && <VerifiedBadge size="xs" />}
              </div>
              <span className="text-[8.5px] text-emerald-400 font-medium leading-none block">Active now</span>
            </div>
          </div>
        </div>

        {/* Action buttons: Voice Call, Video Call, Search, Settings */}
        <div className="flex items-center gap-0.5 shrink-0">
          {/* Voice Call Button */}
          <button
            type="button"
            onClick={() => handleInitiateCall('voice')}
            className="p-1 rounded-lg text-neutral-300 hover:text-[#25f4ee] hover:bg-white/10 cursor-pointer transition-colors"
            title="Start Voice Call"
          >
            <Phone className="w-3.5 h-3.5" />
          </button>

          {/* Video Call Button */}
          <button
            type="button"
            onClick={() => handleInitiateCall('video')}
            className="p-1 rounded-lg text-neutral-300 hover:text-[#25f4ee] hover:bg-white/10 cursor-pointer transition-colors"
            title="Start Video Call"
          >
            <Video className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsSearching(prev => !prev)}
            className={`p-1 rounded-lg text-neutral-400 hover:text-white cursor-pointer ${isSearching ? 'bg-white/10 text-[#25f4ee]' : ''}`}
            title="Search Messages"
          >
            <Search className="w-3.5 h-3.5" />
          </button>
          
          <button
            onClick={() => setShowSettings(prev => !prev)}
            className="p-1 rounded-lg text-neutral-400 hover:text-white cursor-pointer"
            title="Chat Options"
          >
            <MoreVertical className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Search Header Bar */}
      {isSearching && (
        <div className="p-1.5 bg-neutral-950 border-b border-white/10 flex items-center gap-1.5 shrink-0">
          <Search className="w-3 h-3 text-neutral-400 ml-1" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search messages..."
            className="flex-1 bg-black border border-white/10 rounded-md px-2 py-0.5 text-[11px] text-white focus:outline-none focus:border-[#25f4ee]"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="p-1 text-neutral-400 hover:text-white">
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
      )}

      {/* Pinned Message Banner */}
      {pinnedMessage && (
        <div className="p-1.5 bg-neutral-950 border-b border-[#25f4ee]/30 flex items-center justify-between text-[10.5px] px-2.5 shrink-0 shadow-sm">
          <div className="flex items-center gap-1.5 text-neutral-300 line-clamp-1 text-[10px]">
            <Pin className="w-2.5 h-2.5 text-[#25f4ee] shrink-0" />
            <span className="font-bold text-white shrink-0">Pinned:</span>
            <span className="line-clamp-1">{pinnedMessage.text}</span>
          </div>
          <button onClick={() => setPinnedMessage(null)} className="p-0.5 text-neutral-400 hover:text-white cursor-pointer">
            <X className="w-2.5 h-2.5" />
          </button>
        </div>
      )}

      {/* Settings / Wallpaper Dropdown */}
      {showSettings && (
        <div className="p-2 bg-neutral-950 border-b border-white/10 flex flex-col gap-1.5 shrink-0 animate-in slide-in-from-top-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-neutral-300">Chat Theme</span>
            <button onClick={() => setShowSettings(false)} className="text-neutral-400 hover:text-white">
              <X className="w-3 h-3" />
            </button>
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
            {Object.entries(CHAT_WALLPAPERS).map(([key, theme]) => (
              <button
                key={key}
                onClick={() => setWallpaperTheme(key)}
                className={`px-2 py-0.5 rounded-full text-[9px] font-bold shrink-0 border transition-colors cursor-pointer ${
                  wallpaperTheme === key
                    ? 'border-[#25f4ee] bg-[#25f4ee]/20 text-[#25f4ee]'
                    : 'border-white/10 bg-neutral-900 text-neutral-400 hover:text-white'
                }`}
              >
                {theme.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Chat Messages Feed */}
      <div className={`flex-1 overflow-y-auto p-3 space-y-2 ${currentTheme.bgClass}`}>
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-4 space-y-2 opacity-60">
            <img
              src={displayAvatar}
              alt={displayHandle}
              className="w-12 h-12 rounded-full object-cover border border-white/15 mb-0.5"
            />
            <h4 className="text-xs font-bold text-white">{displayUsername}</h4>
            <p className="text-[10px] text-neutral-400 max-w-xs">
              Say hello! Direct messages, voice calls, and video calls on Pulse are live and private.
            </p>
          </div>
        ) : (
          filteredMessages.map((msg) => {
            const isMe = msg.senderUid === currentUser.uid;
            const isVoice = msg.mediaType === 'voice' || (msg.voiceDuration && msg.voiceDuration > 0);
            const isCallLog = msg.mediaType === 'call_log' || !!msg.callLog;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} group relative`}
              >
                <div className="flex items-end gap-1 max-w-[88%] sm:max-w-[82%]">
                  {!isMe && (
                    <img
                      src={displayAvatar}
                      alt={displayHandle}
                      className="w-5 h-5 rounded-full object-cover border border-white/20 shrink-0 mb-0.5"
                    />
                  )}

                  {/* CALL LOG MESSAGE CARD */}
                  {isCallLog ? (
                    <div className="p-2 rounded-xl bg-neutral-900/90 border border-white/10 flex items-center gap-2 shadow-sm max-w-[240px]">
                      <div className={`p-1.5 rounded-full ${
                        msg.callLog?.status === 'declined' || msg.callLog?.status === 'missed'
                          ? 'bg-red-500/20 text-red-400'
                          : 'bg-emerald-500/20 text-emerald-400'
                      }`}>
                        {msg.callLog?.callType === 'video' ? <Video className="w-3.5 h-3.5" /> : <Phone className="w-3.5 h-3.5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-[11px] font-bold text-white leading-tight">
                          {msg.text || (msg.callLog?.callType === 'video' ? 'Video Call' : 'Voice Call')}
                        </div>
                        <div className="text-[9px] text-neutral-400">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleInitiateCall(msg.callLog?.callType || 'voice')}
                        className="px-1.5 py-0.5 rounded bg-white/10 hover:bg-[#25f4ee] hover:text-black text-[#25f4ee] text-[9.5px] font-bold cursor-pointer transition-colors"
                      >
                        Call
                      </button>
                    </div>
                  ) : (
                    /* REGULAR / VOICE / PHOTO MESSAGE BUBBLE */
                    <div
                      className={`p-2 rounded-xl text-[11px] relative ${
                        isMe
                          ? 'bg-gradient-to-tr from-[#25f4ee] to-[#00b4d8] text-black font-medium rounded-br-xs shadow-xs'
                          : 'bg-neutral-800/90 text-white rounded-bl-xs border border-white/10'
                      }`}
                    >
                      {/* VOICE NOTE COMPONENT */}
                      {isVoice && msg.mediaUrl ? (
                        <VoiceNotePlayer
                          mediaUrl={msg.mediaUrl}
                          duration={msg.voiceDuration || 0}
                          isMe={isMe}
                        />
                      ) : (
                        <>
                          {/* Media image or GIF if present */}
                          {(msg.mediaUrl || msg.gifUrl) && (
                            <img
                              src={msg.mediaUrl || msg.gifUrl}
                              alt="Shared media"
                              className="rounded-lg max-h-48 w-auto object-cover mb-1 border border-black/10"
                            />
                          )}

                          {/* Text content */}
                          {msg.text && <p className="whitespace-pre-wrap leading-snug">{msg.text}</p>}
                        </>
                      )}

                      {/* Footer timestamp & delivery check */}
                      <div className="flex items-center justify-end gap-0.5 mt-0.5 text-[8.5px] opacity-70">
                        <span>{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        {isMe && <CheckCheck className="w-2.5 h-2.5" />}
                      </div>

                      {/* Reaction Display */}
                      {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                        <div className="absolute -bottom-2 right-1 flex items-center gap-0.5 bg-neutral-900 border border-white/20 rounded-full px-1 py-0.2 shadow-sm">
                          {Object.values(msg.reactions).map((emoji, idx) => (
                            <span key={idx} className="text-[9px]">{emoji}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Hover / Quick Reaction Bar */}
                {!isCallLog && (
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-0.5 mt-0.5 px-1">
                    <div className="flex bg-neutral-900/90 border border-white/15 rounded-full p-0.5 shadow-sm gap-0.5">
                      {EMOJI_REACTIONS.slice(0, 5).map(emoji => (
                        <button
                          key={emoji}
                          onClick={() => handleReact(msg.id, emoji)}
                          className="text-[10px] hover:scale-125 transition-transform p-0.5 cursor-pointer"
                        >
                          {emoji}
                        </button>
                      ))}
                      <button
                        onClick={() => setReplyingTo(msg)}
                        title="Reply"
                        className="p-0.5 text-neutral-400 hover:text-white cursor-pointer text-[10px]"
                      >
                        <Reply className="w-2.5 h-2.5" />
                      </button>
                      <button
                        onClick={() => handleTogglePin(msg)}
                        title="Pin message"
                        className="p-0.5 text-neutral-400 hover:text-white cursor-pointer text-[10px]"
                      >
                        <Pin className="w-2.5 h-2.5" />
                      </button>
                      {isMe && (
                        <button
                          onClick={() => handleDelete(msg.id)}
                          title="Unsend"
                          className="p-0.5 text-neutral-400 hover:text-red-400 cursor-pointer text-[10px]"
                        >
                          <Trash2 className="w-2.5 h-2.5" />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quoted Message Preview Bar */}
      {replyingTo && (
        <div className="p-1.5 bg-neutral-900 border-t border-white/10 flex items-center justify-between px-3 text-[10.5px] shrink-0">
          <div className="flex items-center gap-1.5">
            <Reply className="w-3 h-3 text-[#25f4ee]" />
            <div className="line-clamp-1">
              <span className="text-neutral-400 font-bold mr-1">Replying to:</span>
              <span className="text-white">{replyingTo.text}</span>
            </div>
          </div>
          <button onClick={() => setReplyingTo(null)} className="text-neutral-400 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Attached Image Preview */}
      {mediaUrl && (
        <div className="p-1.5 bg-neutral-900 border-t border-white/10 flex items-center justify-between px-3 shrink-0">
          <div className="flex items-center gap-1.5">
            <img src={mediaUrl} alt="Upload preview" className="w-9 h-9 rounded-lg object-cover border border-white/20" />
            <span className="text-[10px] text-neutral-300">Photo attached</span>
          </div>
          <button onClick={() => setMediaUrl(null)} className="p-0.5 text-neutral-400 hover:text-white cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* GIF Picker Modal */}
      {showGifPicker && (
        <div className="p-2 bg-neutral-950 border-t border-white/10 max-h-40 overflow-y-auto space-y-1.5 shrink-0">
          <div className="flex items-center justify-between text-[11px] font-bold text-white">
            <span>Trending GIFs</span>
            <button onClick={() => setShowGifPicker(false)} className="text-neutral-400 hover:text-white">
              <X className="w-3 h-3" />
            </button>
          </div>
          <div className="grid grid-cols-3 gap-1">
            {[
              'https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif',
              'https://media.giphy.com/media/artj92V8o75VPL7AeQ/giphy.gif',
              'https://media.giphy.com/media/3o7TKSjRrfIPjeiVyM/giphy.gif',
              'https://media.giphy.com/media/26AHONQ79FdWZhAI0/giphy.gif',
              'https://media.giphy.com/media/xT9IgzoKnwFNmISR8I/giphy.gif',
              'https://media.giphy.com/media/3oKIPnAiaMCws8nOsE/giphy.gif'
            ].map((gif, i) => (
              <img
                key={i}
                src={gif}
                alt="GIF"
                onClick={() => handleSendGif(gif)}
                className="h-14 w-full object-cover rounded-md cursor-pointer hover:scale-105 transition-transform border border-white/10"
              />
            ))}
          </div>
        </div>
      )}

      {/* Real Live Voice Note Recorder Bar */}
      {isRecordingVoice ? (
        <VoiceNoteRecorder
          onSend={handleSendVoiceBlob}
          onCancel={() => setIsRecordingVoice(false)}
          onToast={onToast}
        />
      ) : (
        /* Chat Input Toolbar */
        <div className="p-1.5 bg-black border-t border-white/10 shrink-0">
          <form onSubmit={handleSend} className="flex items-center gap-1">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageSelect}
              accept="image/*"
              className="hidden"
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 cursor-pointer transition-colors"
              title="Attach Photo"
            >
              <ImageIcon className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => setShowGifPicker(prev => !prev)}
              className="px-1 py-0.5 rounded text-[9px] font-bold text-neutral-400 hover:text-white hover:bg-white/10 cursor-pointer uppercase border border-white/10"
              title="Send GIF"
            >
              GIF
            </button>

            <input
              type="text"
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              placeholder="Send a message..."
              className="flex-1 bg-neutral-950 border border-white/10 rounded-lg px-2.5 py-1 text-[11px] text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#25f4ee]"
            />

            {inputText.trim() || mediaUrl ? (
              <button
                type="submit"
                disabled={sending}
                className="w-6 h-6 rounded-md bg-[#25f4ee] hover:bg-[#1ee0da] text-black flex items-center justify-center shadow-xs transition-transform active:scale-95 cursor-pointer font-bold shrink-0"
              >
                <Send className="w-3 h-3 text-black ml-0.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setIsRecordingVoice(true)}
                className="p-1 rounded-lg text-neutral-400 hover:text-[#25f4ee] hover:bg-white/10 cursor-pointer transition-colors"
                title="Record Voice Note"
              >
                <Mic className="w-3.5 h-3.5" />
              </button>
            )}
          </form>
        </div>
      )}

    </div>
  );
};
